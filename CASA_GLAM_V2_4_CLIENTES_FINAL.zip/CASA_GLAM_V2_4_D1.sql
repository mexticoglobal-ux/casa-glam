CREATE TABLE IF NOT EXISTS client_followups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id INTEGER NOT NULL,
  service TEXT NOT NULL,
  service_date TEXT NOT NULL,
  due_date TEXT NOT NULL,
  notes TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Pendiente' CHECK(status IN ('Pendiente','Realizado','Cancelado')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(client_id) REFERENCES clients(id)
);
CREATE INDEX IF NOT EXISTS idx_followups_due ON client_followups(status,due_date);
