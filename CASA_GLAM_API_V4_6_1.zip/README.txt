Casa Glam API

Deploy this worker with:

- `worker.js`
- `wrangler.toml`

Required bindings:
- D1 database binding named `DB`
- secret `ADMIN_PIN`

New payment fields stored on `appointments`:
- `total_amount`
- `amount_paid`
- `payment_method`
- `payment_status`
- `payment_note`
- `payment_updated_at`

Main routes:
- `POST /api/admin/login`
- `GET /api/admin/appointments`
- `GET /api/admin/cobros`
- `PUT /api/admin/appointments/:id`
- `PUT /api/admin/cobros/:id`
- `GET /api/admin/clients/:id`
