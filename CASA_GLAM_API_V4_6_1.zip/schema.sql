ALTER TABLE appointments ADD COLUMN total_amount REAL NOT NULL DEFAULT 0;
ALTER TABLE appointments ADD COLUMN amount_paid REAL NOT NULL DEFAULT 0;
ALTER TABLE appointments ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'Efectivo';
ALTER TABLE appointments ADD COLUMN payment_status TEXT NOT NULL DEFAULT 'Sin cobro';
ALTER TABLE appointments ADD COLUMN payment_note TEXT NOT NULL DEFAULT '';
ALTER TABLE appointments ADD COLUMN payment_updated_at TEXT;
