const API_BASE='https://casa-glam-api.novamarketingstudiocr.workers.dev';
const $=id=>document.getElementById(id); const esc=s=>String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
let settings={open:'09:00',close:'18:00',slot:60,pros:['Pamela González'],services:[]}; let adminPin=sessionStorage.getItem('cg_admin_pin')||''; let adminAppointments=[]; let adminClients=[]; let appointmentFilter='all';
function options(el,arr){el.innerHTML=arr.map(x=>`<option>${esc(x)}</option>`).join('')}
function slots(){let out=[],[h,m]=settings.open.split(':').map(Number),[eh,em]=settings.close.split(':').map(Number),a=h*60+m,b=eh*60+em;for(let x=a;x<b;x+=+settings.slot)out.push(`${String(Math.floor(x/60)).padStart(2,'0')}:${String(x%60).padStart(2,'0')}`);return out}
async function api(url,opt={}){const target=url.startsWith('/api')?API_BASE+url:url;const r=await fetch(target,opt);let data={};try{data=await r.json()}catch{}if(!r.ok)throw new Error(data.error||'No se pudo completar la solicitud.');return data}
async function loadConfig(){try{const d=await api('/api/config');settings={open:d.settings?.open||'09:00',close:d.settings?.close||'18:00',slot:+(d.settings?.slot||60),pros:(d.professionals||[]).map(x=>x.name),services:(d.services||[]).map(x=>x.name)};options($('service'),settings.services);options($('professional'),settings.pros);options($('time'),slots());$('date').min=new Date().toISOString().slice(0,10)}catch(e){$('bookingMsg').textContent='No se pudo conectar con la agenda online. Intenta nuevamente.'}}
async function refreshAvailability(){if(!$('date').value||!$('professional').value)return;try{const q=new URLSearchParams({date:$('date').value,professional:$('professional').value});const d=await api('/api/availability?'+q);const available=(d.slots||[]).filter(x=>x.available).map(x=>x.time);const occupied=(d.slots||[]).filter(x=>!x.available).map(x=>x.time);options($('time'),available);if(!available.length){$('bookingMsg').textContent='⚠️ No quedan horarios disponibles para '+$('date').value+' con '+$('professional').value+'. Selecciona otro día.'}else if(occupied.length){$('bookingMsg').textContent='Horarios ocupados: '+occupied.join(', ')+'. Solo puedes seleccionar horarios disponibles.'}else{$('bookingMsg').textContent='Horarios disponibles para esa fecha.'}}catch(e){$('bookingMsg').textContent=e.message}}
$('date').onchange=refreshAvailability;$('professional').onchange=refreshAvailability;
document.querySelectorAll('[data-service]').forEach(b=>b.onclick=()=>{$('service').value=b.dataset.service;location.hash='reservar'});
$('bookingForm').onsubmit=async e=>{e.preventDefault();const btn=e.submitter;btn.disabled=true;let a={name:$('clientName').value.trim(),phone:$('clientPhone').value.trim(),service:$('service').value,professional:$('professional').value,date:$('date').value,time:$('time').value,notes:$('notes').value.trim()};try{await api('/api/appointments',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(a)});$('bookingMsg').textContent='¡Cita guardada online! Abriendo WhatsApp como confirmación adicional…';let msg=`Hola Casa Glam ✨ Acabo de reservar esta cita:\nNombre: ${a.name}\nServicio: ${a.service}\nProfesional: ${a.professional}\nFecha: ${a.date}\nHora: ${a.time}${a.notes?'\nNotas: '+a.notes:''}`;window.open('https://wa.me/50671286540?text='+encodeURIComponent(msg),'_blank');e.target.reset();await loadConfig()}catch(err){$('bookingMsg').textContent=err.message;await refreshAvailability()}finally{btn.disabled=false}};
function adminHeaders(){return {'x-admin-pin':adminPin,'content-type':'application/json'}}

async function loadAdminBase(){
  const [aRes,cfgRes,clRes] = await Promise.allSettled([
    api('/api/admin/appointments',{headers:adminHeaders()}),
    api('/api/config'),
    api('/api/admin/clients',{headers:adminHeaders()})
  ]);

  adminAppointments = aRes.status==='fulfilled' ? (aRes.value.appointments||[]) : [];
  const cfg = cfgRes.status==='fulfilled' ? cfgRes.value : {settings:{},professionals:[],services:[]};
  settings={
    open:cfg.settings?.open||'09:00',
    close:cfg.settings?.close||'18:00',
    slot:+(cfg.settings?.slot||60),
    pros:(cfg.professionals||[]).map(x=>x.name),
    services:(cfg.services||[]).map(x=>x.name)
  };
  adminClients = clRes.status==='fulfilled' ? (clRes.value.clients||[]) : [];

  renderClients();
  renderAdmin();

  $('openTime').value=settings.open;
  $('closeTime').value=settings.close;
  $('slotMinutes').value=settings.slot;
  $('pros').value=settings.pros.join('\n');
  $('servicesCfg').value=settings.services.join('\n');

  const [dashRes,remRes] = await Promise.allSettled([
    api('/api/admin/dashboard',{headers:adminHeaders()}),
    api('/api/admin/reminders',{headers:adminHeaders()})
  ]);
  renderDashboard(dashRes.status==='fulfilled' ? dashRes.value : null);
  renderReminders(remRes.status==='fulfilled' ? remRes.value : null);
}

const loadAdmin = loadAdminBase;

async function login(){
  adminPin=$('adminPin').value.trim();
  $('loginMsg').textContent='';
  try{
    await api('/api/admin/login',{method:'POST',headers:adminHeaders(),body:JSON.stringify({pin:adminPin})});
    sessionStorage.setItem('cg_admin_pin',adminPin);
    $('adminLogin').hidden=true;
    $('adminPanel').hidden=false;
    await loadAdminBase(); setAppointmentFilter(appointmentFilter);
  }catch(e){
    adminPin='';
    sessionStorage.removeItem('cg_admin_pin');
    $('loginMsg').textContent='No se pudo entrar. Verifica el PIN o vuelve a cargar la página.';
  }
}

$('loginBtn').onclick=login;
$('adminPin').onkeydown=e=>{if(e.key==='Enter')login()};
$('logoutBtn').onclick=()=>{
  adminPin='';
  sessionStorage.removeItem('cg_admin_pin');
  $('adminPanel').hidden=true;
  $('adminLogin').hidden=false;
  $('adminPin').value='';
};
function renderDashboard(d){const x=d?.summary||{};$('todayCount').textContent=x.today||0;$('tomorrowCount').textContent=x.tomorrow||0;$('pendingCount').textContent=x.pending||0;$('confirmedCount').textContent=x.confirmed||0;$('reprogrammedCount').textContent=x.reprogrammed||0;$('clientCount').textContent=x.clients||0;$('recurrentCount').textContent=x.recurrent||0;$('attendedMonthCount').textContent=x.attendedMonth||0;$('reminderCount').textContent=x.reminders||0;const daily=d?.daily||[],max=Math.max(1,...daily.map(x=>+x.total||0));$('weekChart').innerHTML=daily.map(x=>{const dt=new Date(x.date+'T12:00:00'),day=dt.toLocaleDateString('es-CR',{weekday:'short'});const pct=Math.max(6,Math.round((+x.total||0)/max*100));return `<div class="bar-item"><div class="bar-track"><div class="bar-fill" style="height:${pct}%"></div></div><strong>${+x.total||0}</strong><span>${esc(day)}</span></div>`}).join('');const top=d?.topServices||[];$('topServices').innerHTML=top.length?top.map((x,i)=>`<div class="top-service"><span>${i+1}. ${esc(x.service)}</span><strong>${x.total}</strong></div>`).join(''):'<p>Aún no hay datos este mes.</p>'}
function reminderWa(phone,msg){let p=String(phone||'').replace(/\D/g,'').replace(/^506/,'');return `https://wa.me/506${p}?text=${encodeURIComponent(msg)}`}
function renderReminders(d){const a=d?.appointments||[],f=d?.followups||[],rows=[];a.forEach(x=>{const when=x.reminder_type==='2h'?'en menos de 2 horas':'dentro de 24 horas';const msg=`Hola ${x.name} 👋 Te recordamos tu cita en Casa Glam ${x.date} a las ${x.time} con ${x.professional}. Servicio: ${x.service}. ¡Te esperamos!`;rows.push(`<div class="reminder-row"><div><strong>📅 ${esc(x.name)}</strong><p>${esc(x.service)} · ${esc(x.date)} ${esc(x.time)} · ${when}</p></div><a target="_blank" href="${reminderWa(x.phone,msg)}">Enviar WhatsApp</a></div>`) });f.forEach(x=>{const msg=`Hola ${x.name} 🌸 Te escribimos de Casa Glam. Ya se acerca el momento recomendado para renovar tu ${x.service}. ¿Deseas que te ayudemos a reservar tu próxima cita?`;rows.push(`<div class="reminder-row followup"><div><strong>✨ ${esc(x.name)}</strong><p>${esc(x.service)} · seguimiento para ${esc(x.due_date)}</p></div><a target="_blank" href="${reminderWa(x.phone,msg)}">Enviar WhatsApp</a></div>`) });$('remindersList').innerHTML=rows.length?rows.join(''):'<p>No hay recordatorios pendientes en este momento.</p>'}
$('refreshReminders').onclick=async()=>{try{const [d,r]=await Promise.all([api('/api/admin/dashboard',{headers:adminHeaders()}),api('/api/admin/reminders',{headers:adminHeaders()})]);renderDashboard(d);renderReminders(r)}catch(e){alert(e.message)}};

function appointmentMoment(a){return new Date(a.date+'T'+a.time+':00')}
function reminderLabel(a){if(a.status==='Cancelada'||a.status==='Atendida')return '';const now=new Date(),dt=appointmentMoment(a),diff=dt-now,hours=diff/36e5;const today=now.toISOString().slice(0,10),tomorrow=new Date(now.getTime()+864e5).toISOString().slice(0,10);if(diff<0)return 'Hora pasada';if(a.date===today&&hours<=2)return '🔔 En menos de 2 horas';if(a.date===today)return '🔔 Hoy';if(a.date===tomorrow)return '🔔 Mañana';if(hours<=48)return '🔔 Próxima';return ''}
function apptCard(a,cancelled=false){const badge=reminderLabel(a);const phone=a.phone.replace(/\D/g,'').replace(/^506/,'');const msg='Hola '+a.name+' 👋 Te recordamos tu cita en Casa Glam el '+a.date+' a las '+a.time+' con '+a.professional+'. Servicio: '+a.service+'. Si necesitas realizar un cambio, escríbenos por este medio.';return `<div class="appt ${cancelled?'appt-cancelled':''}"><div><h4>${esc(a.date)} · ${esc(a.time)} — ${esc(a.name)} ${badge?`<span class="reminder-badge">${badge}</span>`:''}</h4><p>${esc(a.service)} · ${esc(a.professional)}</p><p>${esc(a.phone)}${a.notes?' · '+esc(a.notes):''}</p></div><div class="appt-actions"><select data-status="${a.id}">${['Pendiente','Confirmada','Reprogramada','Atendida','Cancelada'].map(s=>`<option ${s===a.status?'selected':''}>${s}</option>`).join('')}</select>${!cancelled?`<a target="_blank" href="https://wa.me/506${phone}?text=${encodeURIComponent(msg)}">Recordar por WhatsApp</a>`:''}</div></div>`}
function renderAdmin(){const filteredBase=adminAppointments.filter(apptMatchesFilter);const active=filteredBase.filter(a=>a.status!=='Cancelada').sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));const cancelled=filteredBase.filter(a=>a.status==='Cancelada').sort((a,b)=>(b.date+b.time).localeCompare(a.date+a.time));let html=active.length?active.map(a=>apptCard(a)).join(''):'<p>No hay citas para este filtro.</p>';if(cancelled.length&&(appointmentFilter==='all'||appointmentFilter==='cancelled'))html+=`<details class="cancelled-history"><summary>Ver citas canceladas (${cancelled.length})</summary>${cancelled.map(a=>apptCard(a,true)).join('')}</details>`;$('appointments').innerHTML=html;document.querySelectorAll('[data-status]').forEach(x=>x.onchange=async()=>{try{await api('/api/admin/appointments/'+x.dataset.status,{method:'PUT',headers:adminHeaders(),body:JSON.stringify({status:x.value,pin:adminPin})});await loadAdmin()}catch(e){alert(e.message)}})}
$('saveSettings').onclick=async()=>{const btn=$('saveSettings');const payload={open:$('openTime').value,close:$('closeTime').value,slot:+$('slotMinutes').value,professionals:$('pros').value.split('\n').map(x=>x.trim()).filter(Boolean),services:$('servicesCfg').value.split('\n').map(x=>x.trim()).filter(Boolean),pin:adminPin};if(!payload.open||!payload.close||payload.open>=payload.close)return alert('Revisa el horario de apertura y cierre.');if(!payload.professionals.length)return alert('Debe existir al menos un profesional.');if(!payload.services.length)return alert('Debe existir al menos un servicio.');btn.disabled=true;try{await api('/api/admin/config',{method:'PUT',headers:adminHeaders(),body:JSON.stringify(payload)});await loadAdmin();await loadConfig();alert('Configuración guardada correctamente.');}catch(e){alert(e.message)}finally{btn.disabled=false}};
$('exportBtn').onclick=()=>{let rows=[['Nombre','WhatsApp','Servicio','Profesional','Fecha','Hora','Estado','Notas'],...adminAppointments.map(a=>[a.name,a.phone,a.service,a.professional,a.date,a.time,a.status,a.notes])];let csv=rows.map(r=>r.map(v=>'"'+String(v||'').replace(/"/g,'""')+'"').join(',')).join('\n');let u=URL.createObjectURL(new Blob([csv],{type:'text/csv'})),a=document.createElement('a');a.href=u;a.download='casa-glam-citas.csv';a.click();URL.revokeObjectURL(u)};

function fmtDate(d){if(!d)return '—';try{return new Date(d+'T12:00:00').toLocaleDateString('es-CR',{year:'numeric',month:'short',day:'numeric'})}catch{return d}}
function renderClients(q=''){const el=$('clientsList');if(!el)return;const term=q.trim().toLowerCase();const rows=adminClients.filter(c=>!term||String(c.name||'').toLowerCase().includes(term)||String(c.phone||'').includes(term));el.innerHTML=rows.length?rows.map(c=>`<div class="client-row"><div><h4>${esc(c.name)}</h4><p>WhatsApp: ${esc(c.phone)}</p><p>${c.appointments||0} citas · Última visita: ${fmtDate(c.last_visit)} · Próxima: ${fmtDate(c.next_appointment)}</p></div><button type="button" data-client="${c.id}">Ver ficha</button></div>`).join(''):'<p>No se encontraron clientes.</p>';document.querySelectorAll('[data-client]').forEach(b=>b.onclick=()=>openClient(+b.dataset.client))}
$('clientSearch').oninput=e=>renderClients(e.target.value);
async function openClient(id){try{const d=await api('/api/admin/clients/'+id,{headers:adminHeaders()});const c=d.client,h=d.history||[],f=d.followups||[];const phone=String(c.phone||'').replace(/\D/g,'').replace(/^506/,'');const due=f.filter(x=>x.status==='Pendiente');$('clientDetail').hidden=false;$('clientDetail').innerHTML=`<div class="client-detail"><div class="client-head"><div><p class="eyebrow">FICHA DE CLIENTE</p><h4>${esc(c.name)}</h4><p>${esc(c.phone)} · Cliente desde ${fmtDate((c.created_at||'').slice(0,10))}</p><p><strong>${h.length}</strong> citas registradas · <strong>${due.length}</strong> seguimientos pendientes</p></div><div class="crm-actions"><a target="_blank" href="https://wa.me/506${phone}">WhatsApp</a><button type="button" id="closeClient">Cerrar</button></div></div><h4>Próximos mantenimientos</h4><div>${f.length?f.map(x=>{const msg=`Hola ${c.name} 👋 Te escribimos de Casa Glam. Según tu historial, ya se acerca el momento recomendado para tu ${x.service}. ¿Deseas que te ayudemos a reservar tu próxima cita?`;return `<div class="followup-card"><strong>${esc(x.service)}</strong><p>Realizado: ${fmtDate(x.service_date)} · Recordar: <span class="followup-due">${fmtDate(x.due_date)}</span></p>${x.notes?`<p>${esc(x.notes)}</p>`:''}<div class="crm-actions"><a target="_blank" href="https://wa.me/506${phone}?text=${encodeURIComponent(msg)}">Recordar por WhatsApp</a><button data-followup-done="${x.id}">Marcar realizado</button></div></div>`}).join(''):'<p>Aún no hay mantenimientos programados.</p>'}</div><h4>Agregar seguimiento</h4><div class="crm-form"><label>Servicio<input id="fuService" value=""></label><label>Fecha realizada<input id="fuDate" type="date" value="${new Date().toISOString().slice(0,10)}"></label><label>Recordar en<select id="fuMonths"><option value="1">1 mes</option><option value="2">2 meses</option><option value="3" selected>3 meses</option><option value="4">4 meses</option><option value="6">6 meses</option></select></label><label>Fecha recomendada<input id="fuDue" type="date"></label><label class="wide">Notas<input id="fuNotes" placeholder="Ej: Keratina, fórmula, tono, observaciones..."></label><button class="primary wide" id="saveFollowup" type="button">Guardar seguimiento</button></div><h4>Historial de citas</h4><div class="client-history">${h.length?h.map(a=>`<div class="history-item"><strong>${fmtDate(a.date)} · ${esc(a.service)}</strong><p>${esc(a.professional)} · ${esc(a.status)}${a.notes?' · '+esc(a.notes):''}</p></div>`).join(''):'<p>Sin historial.</p>'}</div></div>`;$('closeClient').onclick=()=>{$('clientDetail').hidden=true};const calcDue=()=>{const base=$('fuDate').value;if(!base)return;const dt=new Date(base+'T12:00:00');dt.setMonth(dt.getMonth()+(+$('fuMonths').value||3));$('fuDue').value=dt.toISOString().slice(0,10)};$('fuDate').onchange=calcDue;$('fuMonths').onchange=calcDue;calcDue();$('saveFollowup').onclick=async()=>{const payload={service:$('fuService').value.trim(),service_date:$('fuDate').value,due_date:$('fuDue').value,notes:$('fuNotes').value.trim()};if(!payload.service||!payload.service_date||!payload.due_date)return alert('Completa servicio y fechas.');await api('/api/admin/clients/'+id+'/followups',{method:'POST',headers:adminHeaders(),body:JSON.stringify(payload)});await openClient(id)};document.querySelectorAll('[data-followup-done]').forEach(b=>b.onclick=async()=>{await api('/api/admin/followups/'+b.dataset.followupDone,{method:'PUT',headers:adminHeaders(),body:JSON.stringify({status:'Realizado'})});await openClient(id)})}catch(e){alert(e.message)}}

loadConfig(); if(adminPin) login();
